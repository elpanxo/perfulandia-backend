package com.perfulandia.pedidos_service.model.dto;

import lombok.Data;

@Data
public class EstadoPedidoRequest {
    private String nuevoEstado;
}