package com.perfulandia.pedidos_service.model;

public class Carrito {
}
